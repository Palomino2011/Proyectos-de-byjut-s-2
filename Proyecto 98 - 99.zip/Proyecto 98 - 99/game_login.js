// Crea la función addUser()
function adduser(){
  
  document.getElementById("player1_name_input").value;
  document.getElementById("player2_name_input").value;
  // Almacena los valores en el almacenamiento local
  localStorage.getItem("player1_name_input");
  localStorage.getItem("player2_name_input");
  //Asigna "game_page.html" a window.location
  window.location = "game_page.html";
}
function send(){
  number1 = document.getElementById("number1").value;
  number2 = document.getElementById("number2").value;
  actual_answer = parseInt(nunber1) * parseInt("number2");
}


